# MP PHARMAI — Backend + Barcode + Multi-branch Starter

This is a development starter package, not a deployed production system. It includes:
- Express/Node API and PostgreSQL schema
- Organization/branch model and branch-scoped access assignments
- Email-verification-before-login flow, password hashing, reset tokens and short-lived JWT access tokens
- Branch-aware stock batches, FEFO-friendly expiry reports, transactional sales and stock transfers
- Barcode/GTIN/SKU product lookup API
- Updated MP PHARMAI HTML prototype with camera barcode scanning (where browser support permits), keyboard scanner entry and branch/transfer demo screens
- Database-backed stock-safety panel for batch quarantine, returns/disposal, routine inspections and saved inspection history
- Operations & launch guide, production gate checklist, test/acceptance plan and SOP templates
- Central medicine reference catalogue and organization product search API

## Prototype and compliance readiness (important)

The dashboard now includes a readiness register that distinguishes safeguards present in the API from tasks that require deployment, evidence, qualified staff, or external approval. It is a project checklist, not a compliance certificate. In particular:

- The API includes authentication, role checks, API rate limits, audit events, purchase receiving, sales, and database-backed batch quarantine/return/disposal controls, but these still require deployment configuration and acceptance testing.
- The main dashboard, ordinary stock/sales/purchases, patient/claims and some reports still use demo/browser-local workflows. Do not use those screens for live transactions or enter real patient information into them.
- This package does not configure production hosting, HTTPS certificates, encrypted backups, backup restoration drills, insurer agreements, or regulator approvals.
- Replace all fictional catalogue, quantity, batch, supplier, price and expiry records with verified source records. A qualified pharmacist must validate medicine identity, registration, prescription status, storage and dispensing procedures.
- Before launch, obtain a documented review against current Rwanda pharmacy/medicines rules, professional requirements and applicable personal-data protection requirements from the competent authorities and qualified local advisers. The software vendor or this prototype cannot certify legal compliance.

Keep evidence for each readiness item (configuration record, test report, approved procedure, training record, licence or written review). Do not treat a visual status label as evidence of completion.

## What is and is not connected

The updated `public/index.html` now has a separate database-connected stock-safety panel. When signed in, staff can select an assigned branch, view PostgreSQL stock batches, quarantine a batch, record a return/disposal, save routine inspections and review saved inspections. The medicine page also has a central database catalogue search. These workflows use authenticated API routes and durable database/audit records. The original dashboard, ordinary stock/sales/purchases, patient/claims and some reports still contain demo/localStorage data. Do not enter real patient data or rely on the demo transaction screens for live operations.

The API expects verified products and batch records. A barcode usually identifies a product package; it does not reliably identify the actual lot/batch and expiry. Staff must confirm batch/expiry on the physical package. The camera feature uses the browser `BarcodeDetector` API where available; camera permission normally requires HTTPS or localhost. USB/Bluetooth scanners that behave like a keyboard can be used in the barcode input.

## Operations and launch documentation

Open `/operations-guide.html` from the running application for the plain-language workflow and launch guide. Supporting controlled-document outlines are in `docs/PRODUCTION_LAUNCH_CHECKLIST.md`, `docs/TEST_AND_ACCEPTANCE_PLAN.md`, and `docs/SOP_TEMPLATES.md`. These are templates and test plans, not evidence of completion or legal approval.

## Requirements

- Node.js 20+
- Docker with Docker Compose (or PostgreSQL 16+)
- SMTP credentials for real verification and password-reset emails

## Local setup

1. Copy `.env.example` to `.env`.
2. In `.env`, set a strong `JWT_SECRET` (at least 32 characters), `DATABASE_URL`, `APP_ORIGIN`, `PUBLIC_APP_URL`, and working SMTP settings.
3. Set `POSTGRES_PASSWORD` in your shell or add it to a Compose-specific `.env` value. For a simple local setup, use the same password in `DATABASE_URL` and `POSTGRES_PASSWORD`.
4. Start PostgreSQL: `docker compose up -d db`
5. Install dependencies: `npm install`
6. Start the app: `npm run dev`
7. Open `http://localhost:3000`.

Database initialization runs `db/schema.sql` on first volume creation. If you already created a database without the schema, apply it explicitly with `psql "$DATABASE_URL" -f db/schema.sql`. Do not delete a production database volume to re-run migrations.

## Customer medicine directory

Open `/clients.html` to use the public customer-facing medicine directory. Customers can search by medicine name/generic name and filter by branch address, area, or neighbourhood. The page calls `GET /api/public/availability`, which returns only medicines with positive stock in an active, available, non-expired batch. It shows the medicine name, strength/form, prescription-required indicator, branch name/address, and starting price. It deliberately does not expose batch/lot numbers, exact stock quantities, supplier information, costs, internal IDs, or patient data.

The directory is informational only: it does not reserve medicines, accept orders, diagnose, or prescribe. Customers are told to confirm stock/prices with the branch and to use pharmacist oversight for prescription medicines. Public listing should only be enabled against verified production data; the current package is still a starter and is not certified for live pharmacy operations.

## Main API routes

All API routes use `/api`. Authenticated routes require `Authorization: Bearer <accessToken>`.

### Authentication
- `POST /api/auth/register` — creates an organization, main branch and owner account; sends verification link; no access until verified.
- `GET /api/auth/verify?token=...` — consumes a short-lived, single-use verification token.
- `POST /api/auth/login` — only verified active accounts receive a 30-minute access token.
- `POST /api/auth/forgot-password` — generic response to avoid revealing whether an account exists.
- `POST /api/auth/reset-password` — uses the expiring token from the email link.
- `GET /api/me` — current account.

Registration requires SMTP configuration and is deliberately unavailable when email cannot be sent. For a real release, add email-change verification, session revocation/refresh-token strategy, login lockout, stronger abuse monitoring and a support workflow.

### Branches and stock
- `GET /api/branches` — only branches assigned to the signed-in user.
- `POST /api/branches` — owner/admin creates a branch.
- `POST /api/branches/:branchId/access` — owner/admin grants an existing same-organization user access.
- `GET /api/stock?branchId=<uuid>` — batches for an authorized branch.
- `POST /api/products` — add product/barcode mapping.
- `GET /api/products/lookup?barcode=<value>` — find product and batch balances by barcode or SKU.
- `GET /api/reports/expiry` — organization expiry/quarantine report
- `POST /api/stock/:batchId/quarantine` — quarantine a batch with a documented reason and audit record
- `POST /api/stock/:batchId/dispositions` — record supplier return or disposal for quarantined/damaged/recalled stock
- `POST /api/inspections` and `GET /api/inspections?branchId=` — save and retrieve routine inspection records
- `GET /api/catalog?search=` — search curated medicine references and organization products.
- `POST /api/sales` — transactional sale; checks branch access, available quantity, batch status and expiry, then records stock movements.
- `POST /api/transfers` — moves source quantity to an in-transit transfer record.
- `POST /api/transfers/:id/receive` — authorized destination user receives the transfer and destination batch balance is updated.

### Sample requests

Create an organization and owner (SMTP must be configured):

```json
POST /api/auth/register
{
  "organizationName": "Example Pharmacy Group",
  "branchName": "Musanze Main",
  "fullName": "Pharmacy Owner",
  "email": "owner@example.com",
  "phone": "+250...",
  "password": "use-a-unique-password-at-least-12-chars"
}
```

Add a product after signing in:

```json
POST /api/products
{
  "name": "Paracetamol",
  "strength": "500 mg",
  "dosageForm": "tablet",
  "barcode": "616110000001",
  "sku": "PCM-500-TAB"
}
```

The stock/purchase receiving API is not yet complete in this starter: batches need to be added through a validated receiving workflow before stock can be sold or transferred. Do not insert unverified or fictitious product data into live operations.

## Important production hardening still required

Before real pharmacy deployment:
1. Complete API integration for every frontend screen and add automated integration tests.
2. Connect the remaining ordinary stock, sales, purchase, patient, reports and settings screens to the API; add supplier management, full stock reconciliation and workflow integration tests.
3. Add CSRF/session strategy appropriate to deployment, refresh-token rotation/revocation, login throttling by account/IP, MFA for privileged roles and secure password reset notifications.
4. Add tenant-isolation and permission tests for every route; ensure users cannot access another organization through crafted IDs.
5. Configure TLS, secrets management, encrypted backups, restore drills, monitoring, alerting and database migrations.
6. Validate medicine catalogue, prescription rules, data privacy, pharmacy record retention and local Rwanda regulatory requirements with qualified professionals.
7. Use a verified email provider, domain authentication (SPF/DKIM/DMARC), and monitored delivery.
8. Conduct a security review and load/concurrency tests before live transactions.

No live database, SMTP provider, hosting, insurer, payment provider or external barcode catalogue is configured by this package.

## Next-step update: API-connected account screens

The account modal in `public/index.html` now calls the backend for registration, email-verification initiation, login, and password-reset initiation. The password-reset page already calls the reset endpoint. The interface also checks `/api/health`. A successful login authenticates the account, but the stock/sales/patients/reports UI still uses browser demo data; do not use this build for real pharmacy operations yet.

Added `POST /api/purchases/receive` for authorized staff to receive product batches into a selected branch. It blocks expired batches and uses a database transaction for the purchase, stock movements, and audit record. See `API-ROUTES.md` for the request format.

## What has and has not been verified

- Syntax checks pass for the Node.js backend and browser JavaScript.
- Live database migrations, SMTP delivery, browser verification clicks, and end-to-end purchase receipt have **not** been run in this environment. Configure `.env`, start PostgreSQL, and test with a dedicated test email before relying on these flows.
- API access tokens are kept in `sessionStorage` for this starter. For a hardened production deployment, consider secure HttpOnly cookies, CSRF protections as applicable, HTTPS, monitored backups, and a security review.


## Database-connected stock safety and medicine catalogue

The HTML prototype includes a broad generic reference list across common therapeutic areas (for example, pain/fever, allergies/asthma, infections, malaria/parasites, gastrointestinal conditions, diabetes, cardiovascular conditions, nutrition, skin, eye/ear, reproductive health and selected neurological conditions). This is not an exhaustive list of all diseases or medicines, a clinical decision support system, or a prescribing guide. Reference entries are not evidence of stock availability. Before any live use, a qualified pharmacist must validate the catalogue against current Rwanda registration requirements, the current national essential medicines list/formulary, local treatment protocols and the pharmacy's authorized scope.

FEFO sorting, quarantine, inspection notes and return/disposal entries are currently browser-local demo functions. They are not yet durable server records or enforced across branches. The demo prevents quarantined batches from being selected for a sale, but production must enforce that rule server-side as well. Device-date alerts are not a reliable substitute for a server-controlled clock.


### Latest integration step

The database schema now includes `stock_inspections`, `stock_control_events`, and `medicine_reference`. The schema seeds a curated starter set of common generic medicine references. Existing databases must be migrated by applying the updated `db/schema.sql` once; do not delete a database volume to force reinitialization. The HTML includes a branch-aware database panel for viewing batches, quarantine, return/disposal, and inspections, plus a central catalogue search. All changes are server-side and transactionally recorded for these specific workflows.

### Remaining limitations

The connected safety panel requires a verified account, configured database and branch stock records created through the API. Product reference entries must be checked against current Rwanda registration and clinical guidance by a qualified pharmacist. This package has passed static JavaScript syntax checks, but database migrations and live HTTP workflows have not been run here because a PostgreSQL service is not available in this environment. The project is not yet ready for real pharmacy operations.


## Subscription plans, payments and owner revenue dashboard

### Plans and limits

The `plans` table is the source of truth for plan prices, feature flags and limits. The seed values in `db/schema.sql` are editable starting prices, not a promise about market pricing:

| Plan | Price | Starting limits |
|---|---:|---|
| 30-day trial | Free for 30 days | 3 branches, 10 users, 1,000 sales/month |
| Free | RWF 0 | 1 branch, 3 users, 300 sales/month; no stock transfers, advanced reports or data export |
| Premium | RWF 15,000/month or RWF 150,000/year | 1 branch, 10 users, 5,000 sales/month; advanced reports and data export |
| Business | RWF 35,000/month or RWF 350,000/year | Up to 20 branches, 100 users, no configured monthly sales cap; stock transfers and advanced reports |

Review and update these values in the `plans` seed before launch. Prices are stored in RWF and the current app only has server-side operational enforcement for branch limits, monthly sale counts, and stock-transfer access. The existing prototype still has demo/localStorage workflows for several screens; do not use those demo screens for real pharmacy transactions. The API-backed sales, inventory and stock-control routes are separate from those demo workflows.

New registrations receive a 30-day trial. After trial or paid-subscription expiry, protected operational API calls return `402 SUBSCRIPTION_EXPIRED`. The owner can still sign in, inspect billing, choose the limited Free plan, or pay to renew. Free-plan selection sets a long-lived active subscription with server-side limits; it does not delete records. Successful payments extend an existing paid subscription from its current expiry date when that date is still in the future, otherwise from the time of payment verification.

### Payment modes

The server supports two modes:

- `PAYMENT_PROVIDER_MODE=test`: development-only checkout. It displays a clear test-only page and can simulate a successful payment in the backend. It is deliberately disabled when `NODE_ENV=production` and does not charge real money.
- `PAYMENT_PROVIDER_MODE=flutterwave`: server creates a Flutterwave Standard checkout using the secret key, and then verifies the transaction server-side before activating the subscription. The browser redirect is not trusted by itself. The webhook endpoint also checks Flutterwave's `verif-hash` against `FLW_WEBHOOK_SECRET_HASH`, then re-verifies the transaction with Flutterwave. Manual MoMo is separate: customers submit the official MoMo transaction ID, and the platform owner must check the actual incoming transaction in the receiving account before using the Confirm received action. Never approve based only on a screenshot or a customer-entered ID.
- `PAYMENT_PROVIDER_MODE=disabled` (or any unrecognized value): Flutterwave/test checkout is unavailable; plan browsing, Free-plan selection, and the manual MoMo request flow remain available.
- `MOMO_PAYMENT_NUMBER=+25079829779`: recipient displayed for the manual Rwanda Mobile Money option. This is a user-provided number; verify the account ownership, registered name, and supported payment method before launch. The app does not automatically verify MoMo transactions. A platform owner must check the official receiving-account statement and manually approve each submitted transaction reference before the subscription activates.

Flutterwave integration follows its documented hosted-checkout and transaction-verification sequence. See [Flutterwave Standard](https://developer.flutterwave.com/docs/flutterwave-standard-1) and [Transaction Verification](https://developer.flutterwave.com/docs/transaction-verification). Confirm RWF and the payment methods you need are enabled for your own merchant account before accepting payments.

### Local setup

1. Copy `.env.example` to `.env` and fill in `DATABASE_URL`, a random `JWT_SECRET` (at least 32 characters), `APP_ORIGIN`, `PUBLIC_APP_URL`, and SMTP credentials.
2. For local development, keep `PAYMENT_PROVIDER_MODE=test`. Never deploy that mode with `NODE_ENV=production`.
3. Set `POSTGRES_PASSWORD` in your local environment or Compose `.env` file, using the same password as `DATABASE_URL`.
4. Start PostgreSQL with `docker compose up -d db`.
5. Apply the schema. For a new database, the Docker initialization script applies it automatically. For an existing database, run `psql "$DATABASE_URL" -f db/schema.sql` to create the new plan/payment tables and seed plans. Back up production data first; do not delete a production volume to rerun initialization.
6. Run `npm install`, then `npm run check`, then `npm run dev`.
7. Open `http://localhost:3000`, create an account, and complete email verification. Test Premium/Business checkout through the development test page. No real money is charged in test mode.

### Automated migration and billing end-to-end checks

- `npm run migrate` applies `db/schema.sql` to the database in `DATABASE_URL` and checks that the four plans plus the subscription/payment tables exist. Use a development or staging database first; back up any database containing real data.
- `npm run test:billing` applies the schema and runs a local HTTP end-to-end flow against a dedicated database set in `TEST_DATABASE_URL`. It creates and removes a temporary test pharmacy, starts the server with the development-only test-payment adapter, and checks plan listing, checkout creation, successful test activation, payment history, duplicate-payment rejection, owner revenue access, MoMo pending/reference/manual approval flow, expiry blocking, Free-plan reactivation and Free-plan branch limits.
- Example: `TEST_DATABASE_URL='postgres://USER:PASSWORD@HOST:5432/trix_test' npm run test:billing`. Do not point this variable at production. The test adapter simulates payment and never charges real money.
- The test script does **not** verify live Flutterwave transactions or deploy the app. Those require your Flutterwave test credentials, webhook setup and a deployed staging service.

### Deploy on Render

1. Create a managed PostgreSQL database in Render and keep its connection string private.
2. Create a Node web service from the project repository. Use build command `npm install` and start command `npm start`. Set the health-check path to `/api/health`. The supplied `render.yaml` includes `preDeployCommand: npm run migrate` for Render services that support pre-deploy commands.
3. Configure the service environment variables: `NODE_ENV=production`, `DATABASE_URL` (Render's internal database URL), `JWT_SECRET` (a new secret of at least 32 characters), `APP_ORIGIN` (the exact HTTPS website origin), `PUBLIC_APP_URL` (the full HTTPS Render URL or custom domain), `PAYMENT_PROVIDER_MODE=flutterwave`, `FLW_SECRET_KEY`, `FLW_WEBHOOK_SECRET_HASH`, `PLATFORM_OWNER_EMAILS`, and all required `SMTP_*` / `MAIL_FROM` values.
4. Ensure the database schema is applied to the managed database. The blueprint pre-deploy command runs `npm run migrate` on supported plans. For an existing manually configured service, open its Render Shell and run `npm run migrate` from the project directory, or run the migration as a one-off job with the same `DATABASE_URL`. Do not delete the database or production volume to fix a missing schema; keep credentials out of source control.
5. In Flutterwave's dashboard, configure the webhook URL as `https://YOUR-DOMAIN/api/billing/flutterwave/webhook` and use the same webhook secret hash as `FLW_WEBHOOK_SECRET_HASH`. Use test credentials and test webhook settings first; switch to live credentials only after tests and merchant onboarding are complete.
6. Register a test pharmacy, verify its email, select Premium, complete a provider test payment, and confirm the database shows a successful payment and an extended subscription. Also test cancelled payments, mismatched amounts/currencies, duplicate webhook deliveries, expired subscriptions and Free-plan limits.
7. Do not claim launch readiness until database backups/restoration, error monitoring, rate limits, security review, pharmacy/privacy requirements and a complete end-to-end payment test have been verified.

### Environment variables

- `PAYMENT_PROVIDER_MODE` — `test`, `flutterwave`, or `disabled` (manual MoMo remains a separate pending/manual-confirmation flow).
- `MOMO_PAYMENT_NUMBER` — recipient number shown in Plans & Billing; never assume the number is correct without verifying account ownership.
- `FLW_SECRET_KEY` — secret key; server only, never put it in HTML or Git.
- `FLW_WEBHOOK_SECRET_HASH` — webhook hash configured in Flutterwave dashboard.
- `FLW_PUBLIC_KEY` — reserved for future client-side provider features; the current hosted-checkout flow does not expose or require it.
- `PLATFORM_OWNER_EMAILS` — comma-separated, normalized email allowlist for the platform-level revenue dashboard. This is distinct from being a pharmacy organization owner.
- `PUBLIC_APP_URL` — public HTTPS origin used in payment callback and email links.

### Troubleshooting: plans missing on Render

- The Plans & Billing page now requests the public plan catalogue even before sign-in; choosing a plan still requires an account.
- If the page reports that the billing database has not been initialized, run `npm run migrate` for the same Render service/database, then reload the page.
- In Render, confirm the service logs show `Migration/schema application succeeded` when the migration runs. Also open `https://YOUR-DOMAIN/api/plans`; a working response is JSON with a `plans` array containing `free`, `premium`, and `business` (plus `trial`).
- If `/api/plans` returns a 503 migration message, the database schema is missing. If it returns an empty `plans` array, confirm that the migration ran against the same `DATABASE_URL` used by the web service.
- A deployment of the code alone does not migrate an already-existing database unless the pre-deploy command is supported/enabled or you run the migration manually.

### Billing API routes

- `GET /api/plans` — public plan catalogue from PostgreSQL.
- `GET /api/subscription` — current subscription, access flag, limits/features and remaining days.
- `GET /api/billing/summary` — current subscription and recent payment history.
- `POST /api/billing/select-free` — owner/admin activates the limited Free plan.
- `POST /api/billing/checkout` — owner/admin starts monthly or annual Premium/Business checkout; provider chooses amount from database, not from client input.
- `GET /api/billing/flutterwave/callback` — verifies provider transaction before activating a subscription.
- `POST /api/billing/flutterwave/webhook` — validates webhook hash and re-verifies the transaction server-side.
- `GET /api/owner/me` — reports whether the signed-in email is on the platform-owner allowlist.
- `GET /api/owner/revenue` — platform-owner-only revenue, plan counts and recent payments.
- `GET /api/billing/test-checkout` and `POST /api/billing/test/complete` — development-only fake checkout; return 404 in production.

The subscription payment table stores pending/successful/failed status, plan, billing interval, amount, currency, provider reference and verified provider transaction ID. A payment reference is unique and transaction activation is performed in a database transaction. The owner dashboard counts only verified successful payments as gross revenue; it does not calculate net profit, fees, refunds or taxes.

### Manual Mobile Money (MoMo)

1. In Plans & Billing, choose **Pay monthly by MoMo** or **Pay annually by MoMo**.
2. Send the exact displayed RWF amount to the configured recipient number `+25079829779` and keep the official transaction ID from the MoMo SMS/receipt.
3. Enter the transaction ID in the app and submit it. The payment stays pending; submitting an ID alone does not activate a plan.
4. A platform owner must open Owner Revenue, inspect the receiving MoMo account's official transaction history, match the exact amount and transaction ID, and only then press **Confirm received**.

This is a manual confirmation workflow, not a direct MTN MoMo API integration. Verify the recipient number, registered account name, and business/merchant setup before publishing the app. Never approve based only on a screenshot or an unverified customer-entered reference.


## Automated CI testing

The repository includes `.github/workflows/ci.yml`. After the project is pushed to GitHub, the workflow starts a disposable PostgreSQL 16 service, installs Node dependencies, runs `npm run check`, then runs `npm run test:billing`. The end-to-end suite covers the test checkout adapter and manual MoMo reference/owner-confirmation flow; it never charges real money. Review the workflow run in GitHub Actions to see whether it passed. This workflow has been added to the source but has not run in this workspace, and it will not run until the project is pushed to a GitHub repository with Actions enabled.

For local execution, set `TEST_DATABASE_URL` to a dedicated disposable PostgreSQL database and run `npm run test:billing`. Never point it at production.



## MP PHARMAI demo inventory note

The browser demo seeds a fictional sample inventory from the built-in reference catalogue, with 25 sample units per catalogue entry (more than 1,500 total units). These are illustrative placeholders only: zero prices, synthetic batch identifiers, and fictional quantities. They are not real medicines held by the pharmacy and must be replaced with physically verified product, batch, expiry, supplier, cost and selling-price records before operational use. Existing browser-saved inventory is preserved rather than overwritten. The PostgreSQL inventory is not automatically populated by this browser demo seed.
